void version1(int grille[10][10], int largeur, int cible);

int AxesCheck1(int grille[10][10], int y, int x, int largeur, int cible);

int writeSolution1(int a, int b, int c, char op, int cible);

int testSolution1(int a, int b, int c, int cible);

void boucle1(int grille[10][10], int largeur, int cible);